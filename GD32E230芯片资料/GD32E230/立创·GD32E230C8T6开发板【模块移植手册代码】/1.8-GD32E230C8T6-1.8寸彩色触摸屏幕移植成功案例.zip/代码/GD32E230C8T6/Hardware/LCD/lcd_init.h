#ifndef __LCD_INIT_H
#define __LCD_INIT_H

#include "gd32e23x.h"
#include "systick.h"

#ifndef u8
#define u8 uint8_t
#endif

#ifndef u16
#define u16 uint16_t
#endif

#ifndef u32
#define u32 uint32_t
#endif


#define USE_HORIZONTAL 1  //���ú�������������ʾ 0��1Ϊ���� 2��3Ϊ����


#if USE_HORIZONTAL==0||USE_HORIZONTAL==1
#define LCD_W 128
#define LCD_H 160

#else
#define LCD_W 160
#define LCD_H 128
#endif

//������оƬ��������
#define TCLK(x)                 gpio_bit_write(GPIOC, GPIO_PIN_13, x?1:0)   //PC13  SCLK--
#define TDIN(x)                 gpio_bit_write(GPIOC, GPIO_PIN_14, x?1:0)   //PC14  MOSI--
#define DOUT                 	gpio_input_bit_get(GPIOA, GPIO_PIN_2)   	//PA2   MISO--
#define TCS(x)                  gpio_bit_write(GPIOA, GPIO_PIN_4, x?1:0)   	//PA4   CS2--
#define PEN                  	gpio_input_bit_get(GPIOA, GPIO_PIN_5)   	//PA5   INT(PEN)--


//-----------------LCD�˿���ֲ---------------- 
//GND  - GND
//VCC  - 3.3V
//CLK  - PC1365
//MOS  - PC14
//RES  - PC15(���Խ��븴λ)
//DC   - PA0
//BLK  - PA1
//MIS  - PA2
//CS1  - PA3      
//CS2  - PA4      
//PEN  - PA5
//NC   - ���ý�

#define RCU_LCD_CLK     RCU_GPIOC//SCK
#define PORT_LCD_CLK    GPIOC
#define GPIO_LCD_CLK    GPIO_PIN_13

#define RCU_LCD_MOS     RCU_GPIOC//MOSI
#define PORT_LCD_MOS    GPIOC
#define GPIO_LCD_MOS    GPIO_PIN_14

#define RCU_LCD_MIS     RCU_GPIOA//MIS0
#define PORT_LCD_MIS    GPIOA
#define GPIO_LCD_MIS    GPIO_PIN_2

#define RCU_LCD_CS1      RCU_GPIOA//NSS
#define PORT_LCD_CS1     GPIOA
#define GPIO_LCD_CS1     GPIO_PIN_3

#define RCU_LCD_CS2      RCU_GPIOA//CS2
#define PORT_LCD_CS2     GPIOA
#define GPIO_LCD_CS2     GPIO_PIN_4

#define RCU_LCD_PEN      RCU_GPIOA //PEN
#define PORT_LCD_PEN     GPIOA
#define GPIO_LCD_PEN     GPIO_PIN_5

#define RCU_LCD_DC      RCU_GPIOA //DC
#define PORT_LCD_DC     GPIOA
#define GPIO_LCD_DC     GPIO_PIN_0

#define RCU_LCD_RES     RCU_GPIOC//RES
#define PORT_LCD_RES    GPIOC
#define GPIO_LCD_RES    GPIO_PIN_15

#define RCU_LCD_BLK     RCU_GPIOA//BLK
#define PORT_LCD_BLK    GPIOA
#define GPIO_LCD_BLK    GPIO_PIN_1
/******** Ӳ��SPI�޸Ĵ˴� ********/
//#define RCU_SPI_HARDWARE RCU_SPI1
//#define PORT_SPI         SPI1
//#define LINE_AF_SPI      GPIO_AF_5




//-----------------LCD�˿ڶ���---------------- 

#define LCD_SCLK_Clr() gpio_bit_write(PORT_LCD_CLK, GPIO_LCD_CLK, RESET)//SCL=SCLK
#define LCD_SCLK_Set() gpio_bit_write(PORT_LCD_CLK, GPIO_LCD_CLK, SET)

#define LCD_MOSI_Clr() gpio_bit_write(PORT_LCD_MOS, GPIO_LCD_MOS, RESET)//SDA=MOSI
#define LCD_MOSI_Set() gpio_bit_write(PORT_LCD_MOS, GPIO_LCD_MOS, SET)

#define LCD_RES_Clr()  gpio_bit_write(PORT_LCD_RES, GPIO_LCD_RES, RESET)//RES
#define LCD_RES_Set()  gpio_bit_write(PORT_LCD_RES, GPIO_LCD_RES, SET)

#define LCD_DC_Clr()   gpio_bit_write(PORT_LCD_DC, GPIO_LCD_DC, RESET)//DC
#define LCD_DC_Set()   gpio_bit_write(PORT_LCD_DC, GPIO_LCD_DC, SET)
                       
#define LCD_CS_Clr()   gpio_bit_write(PORT_LCD_CS1, GPIO_LCD_CS1, RESET)//CS
#define LCD_CS_Set()   gpio_bit_write(PORT_LCD_CS1, GPIO_LCD_CS1, SET)

#define LCD_BLK_Clr()  gpio_bit_write(PORT_LCD_BLK, GPIO_LCD_BLK, RESET)//BLK
#define LCD_BLK_Set()  gpio_bit_write(PORT_LCD_BLK, GPIO_LCD_BLK, SET)





void LCD_GPIO_Init(void);//��ʼ��GPIO
void LCD_Writ_Bus(u8 dat);//ģ��SPIʱ��
void LCD_WR_DATA8(u8 dat);//д��һ���ֽ�
void LCD_WR_DATA(u16 dat);//д�������ֽ�
void LCD_WR_REG(u8 dat);//д��һ��ָ��
void LCD_Address_Set(u16 x1,u16 y1,u16 x2,u16 y2);//�������꺯��
void LCD_Init(void);//LCD��ʼ��
#endif




