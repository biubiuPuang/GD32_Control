#ifndef _SYS_H
#define _SYS_H

#include "gd32e23x.h"
#include "systick.h"


#define BIT_ADDR(byte_offset,bit_number) (volatile unsigned long*)(0x42000000 +(byte_offset << 5)+(bit_number << 2))

#define GPIOA_OCTL_OFFSET ((GPIOA + 0x14) - 0x40000000)
#define GPIOB_OCTL_OFFSET ((GPIOB + 0x14) - 0x40000000)
#define GPIOC_OCTL_OFFSET ((GPIOC + 0x14) - 0x40000000)
#define GPIOD_OCTL_OFFSET ((GPIOD + 0x14) - 0x40000000)
#define GPIOE_OCTL_OFFSET ((GPIOE + 0x14) - 0x40000000)
#define GPIOF_OCTL_OFFSET ((GPIOF + 0x14) - 0x40000000)
#define GPIOG_OCTL_OFFSET ((GPIOG + 0x14) - 0x40000000)

#define PAout(n)    *(BIT_ADDR(GPIOA_OCTL_OFFSET,n))    // ���
#define PBout(n)    *(BIT_ADDR(GPIOB_OCTL_OFFSET,n))    // ���
#define PCout(n)    *(BIT_ADDR(GPIOC_OCTL_OFFSET,n))    // ���
#define PDout(n)    *(BIT_ADDR(GPIOD_OCTL_OFFSET,n))    // ���
#define PEout(n)    *(BIT_ADDR(GPIOE_OCTL_OFFSET,n))    // ���
#define PFout(n)    *(BIT_ADDR(GPIOF_OCTL_OFFSET,n))    // ���
#define PGout(n)    *(BIT_ADDR(GPIOG_OCTL_OFFSET,n))    // ���

#define GPIOA_ISTAT_OFFSET ((GPIOA + 0x10) - 0x40000000)
#define GPIOB_ISTAT_OFFSET ((GPIOB + 0x10) - 0x40000000)
#define GPIOC_ISTAT_OFFSET ((GPIOC + 0x10) - 0x40000000)
#define GPIOD_ISTAT_OFFSET ((GPIOD + 0x10) - 0x40000000)
#define GPIOE_ISTAT_OFFSET ((GPIOE + 0x10) - 0x40000000)
#define GPIOF_ISTAT_OFFSET ((GPIOF + 0x10) - 0x40000000)
#define GPIOG_ISTAT_OFFSET ((GPIOG + 0x10) - 0x40000000)

#define PAin(n)     *(BIT_ADDR(GPIOA_ISTAT_OFFSET,n))   // ����
#define PBin(n)     *(BIT_ADDR(GPIOB_ISTAT_OFFSET,n))   // ����
#define PCin(n)     *(BIT_ADDR(GPIOC_ISTAT_OFFSET,n))   // ����
#define PDin(n)     *(BIT_ADDR(GPIOD_ISTAT_OFFSET,n))   // ����
#define PEin(n)     *(BIT_ADDR(GPIOE_ISTAT_OFFSET,n))   // ����
#define PFin(n)     *(BIT_ADDR(GPIOF_ISTAT_OFFSET,n))   // ����
#define PGin(n)     *(BIT_ADDR(GPIOG_ISTAT_OFFSET,n))   // ����

#endif