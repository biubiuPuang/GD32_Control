#ifndef __LCD_INIT_H
#define __LCD_INIT_H

// lcd_init.h
#include <stdint.h>
#include "gd32e23x.h"
#include "systick.h"


#ifndef u8
#define u8 uint8_t
#endif

#ifndef u16
#define u16 uint16_t
#endif

#ifndef u32
#define u32 uint32_t
#endif


#define USE_HORIZONTAL 2  //���ú�������������ʾ 0��1Ϊ���� 2��3Ϊ����


#if USE_HORIZONTAL==0||USE_HORIZONTAL==1
#define LCD_W 135
#define LCD_H 240

#else
#define LCD_W 240
#define LCD_H 135
#endif


//-----------------LCD�˿���ֲ---------------- 
// 1-VCC    --3.3V
// 2-GND    --GND
// 3-BLK    --PC13
// 4-RES    --PC14
// 5-CS     --PC15
// 6-DC     --PA0
// 7-WR     --PA1
// 8-RD     --PA2
// 9-DB0    --PA3
//10-DB1    --PA4
//11-DB2    --PA5
//12-DB3    --PA6
//13-DB4    --PA7
//14-DB5    --PB0
//15-DB6    --PB1
//16-DB7    --PB10
#define RCU_LCD_RD     RCU_GPIOA//RD
#define PORT_LCD_RD    GPIOA
#define GPIO_LCD_RD    GPIO_PIN_2

#define RCU_LCD_WR     RCU_GPIOA//WR
#define PORT_LCD_WR    GPIOA
#define GPIO_LCD_WR    GPIO_PIN_1

#define RCU_LCD_CS      RCU_GPIOC//CS
#define PORT_LCD_CS     GPIOC
#define GPIO_LCD_CS     GPIO_PIN_15

#define RCU_LCD_DC      RCU_GPIOA //DC
#define PORT_LCD_DC     GPIOA
#define GPIO_LCD_DC     GPIO_PIN_0

#define RCU_LCD_RES     RCU_GPIOC//RES
#define PORT_LCD_RES    GPIOC
#define GPIO_LCD_RES    GPIO_PIN_14

#define RCU_LCD_BLK     RCU_GPIOC//BLK
#define PORT_LCD_BLK    GPIOC
#define GPIO_LCD_BLK    GPIO_PIN_13

#define RCU_LCD_DB0     RCU_GPIOA//DB0
#define PORT_LCD_DB0    GPIOA
#define GPIO_LCD_DB0    GPIO_PIN_3

#define RCU_LCD_DB1     RCU_GPIOA//DB1
#define PORT_LCD_DB1    GPIOA
#define GPIO_LCD_DB1    GPIO_PIN_4

#define RCU_LCD_DB2     RCU_GPIOA//DB2
#define PORT_LCD_DB2    GPIOA
#define GPIO_LCD_DB2    GPIO_PIN_5

#define RCU_LCD_DB3     RCU_GPIOA//DB3
#define PORT_LCD_DB3    GPIOA
#define GPIO_LCD_DB3    GPIO_PIN_6

#define RCU_LCD_DB4     RCU_GPIOA//DB4
#define PORT_LCD_DB4    GPIOA
#define GPIO_LCD_DB4    GPIO_PIN_7

#define RCU_LCD_DB5     RCU_GPIOB//DB5
#define PORT_LCD_DB5    GPIOB
#define GPIO_LCD_DB5    GPIO_PIN_0

#define RCU_LCD_DB6     RCU_GPIOB//DB6
#define PORT_LCD_DB6    GPIOB
#define GPIO_LCD_DB6    GPIO_PIN_1

#define RCU_LCD_DB7     RCU_GPIOB//DB7
#define PORT_LCD_DB7    GPIOB
#define GPIO_LCD_DB7    GPIO_PIN_10




//-----------------LCD�˿ڶ���---------------- 

#define        LCD_RES_Set()       gpio_bit_write(PORT_LCD_RES, GPIO_LCD_RES, SET)//RES 
#define        LCD_CS_Set()        gpio_bit_write(PORT_LCD_CS, GPIO_LCD_CS, SET)//CS
#define        LCD_DC_Set()        gpio_bit_write(PORT_LCD_DC, GPIO_LCD_DC, SET)//DC
#define        LCD_WR_Set()        gpio_bit_write(PORT_LCD_WR, GPIO_LCD_WR, SET)//WR
#define        LCD_RD_Set()        gpio_bit_write(PORT_LCD_RD, GPIO_LCD_RD, SET)//RD
#define        LCD_BLK_Set()       gpio_bit_write(PORT_LCD_BLK, GPIO_LCD_BLK, SET)//BLK

#define        LCD_RES_Clr()       gpio_bit_write(PORT_LCD_RES, GPIO_LCD_RES, RESET)//RES       
#define        LCD_CS_Clr()        gpio_bit_write(PORT_LCD_CS, GPIO_LCD_CS, RESET)//CS
#define        LCD_DC_Clr()        gpio_bit_write(PORT_LCD_DC, GPIO_LCD_DC, RESET)//DC
#define        LCD_WR_Clr()        gpio_bit_write(PORT_LCD_WR, GPIO_LCD_WR, RESET)//WR
#define        LCD_RD_Clr()        gpio_bit_write(PORT_LCD_RD, GPIO_LCD_RD, RESET)//RD
#define        LCD_BLK_Clr()       gpio_bit_write(PORT_LCD_BLK, GPIO_LCD_BLK, RESET)//BLK


// x ? ��1 : ��0                                      
#define PIN_HIGH_OR_LOW(port,gpio,x)  {((x) ? (GPIO_OCTL(port)|=(uint32_t)(gpio)) : (GPIO_OCTL(port)&=~(uint32_t)(gpio)));}

//                  �������λ���ճ�λ��                                    ����x�ж�������λ�������λ 
#define BIT_DB7(x) { GPIO_OCTL(PORT_LCD_DB7) &= ((uint32_t)~(GPIO_LCD_DB7)); PIN_HIGH_OR_LOW( PORT_LCD_DB7, GPIO_LCD_DB7, x) }
#define BIT_DB6(x) { GPIO_OCTL(PORT_LCD_DB6) &= ((uint32_t)~(GPIO_LCD_DB6)); PIN_HIGH_OR_LOW( PORT_LCD_DB6, GPIO_LCD_DB6, x) }
#define BIT_DB5(x) { GPIO_OCTL(PORT_LCD_DB5) &= ((uint32_t)~(GPIO_LCD_DB5)); PIN_HIGH_OR_LOW( PORT_LCD_DB5, GPIO_LCD_DB5, x) }
#define BIT_DB4(x) { GPIO_OCTL(PORT_LCD_DB4) &= ((uint32_t)~(GPIO_LCD_DB4)); PIN_HIGH_OR_LOW( PORT_LCD_DB4, GPIO_LCD_DB4, x) }
#define BIT_DB3(x) { GPIO_OCTL(PORT_LCD_DB3) &= ((uint32_t)~(GPIO_LCD_DB3)); PIN_HIGH_OR_LOW( PORT_LCD_DB3, GPIO_LCD_DB3, x) }
#define BIT_DB2(x) { GPIO_OCTL(PORT_LCD_DB2) &= ((uint32_t)~(GPIO_LCD_DB2)); PIN_HIGH_OR_LOW( PORT_LCD_DB2, GPIO_LCD_DB2, x) }
#define BIT_DB1(x) { GPIO_OCTL(PORT_LCD_DB1) &= ((uint32_t)~(GPIO_LCD_DB1)); PIN_HIGH_OR_LOW( PORT_LCD_DB1, GPIO_LCD_DB1, x) }
#define BIT_DB0(x) { GPIO_OCTL(PORT_LCD_DB0) &= ((uint32_t)~(GPIO_LCD_DB0)); PIN_HIGH_OR_LOW( PORT_LCD_DB0, GPIO_LCD_DB0, x) }




void LCD_GPIO_Init(void);//��ʼ��GPIO
void LCD_Writ_Bus(u8 dat);//ģ��SPIʱ��
void LCD_WR_DATA8(u8 dat);//д��һ���ֽ�
void LCD_WR_DATA(u16 dat);//д�������ֽ�
void LCD_WR_REG(u8 dat);//д��һ��ָ��
void LCD_Address_Set(u16 x1,u16 y1,u16 x2,u16 y2);//�������꺯��
void LCD_Init(void);//LCD��ʼ��
#endif




