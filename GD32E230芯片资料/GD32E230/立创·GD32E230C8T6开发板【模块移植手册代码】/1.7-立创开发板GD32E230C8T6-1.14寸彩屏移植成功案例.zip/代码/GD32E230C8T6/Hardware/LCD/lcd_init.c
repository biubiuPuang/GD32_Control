// lcd_init.c
#include "lcd_init.h"

void LCD_GPIO_Init(void)
{
          /* ʹ��ʱ�� */      
        rcu_periph_clock_enable(RCU_LCD_RD);
        rcu_periph_clock_enable(RCU_LCD_WR);
        rcu_periph_clock_enable(RCU_LCD_CS);
        rcu_periph_clock_enable(RCU_LCD_DC);
        rcu_periph_clock_enable(RCU_LCD_RES);
        rcu_periph_clock_enable(RCU_LCD_BLK);
        rcu_periph_clock_enable(RCU_LCD_DB0);
        rcu_periph_clock_enable(RCU_LCD_DB1);
        rcu_periph_clock_enable(RCU_LCD_DB2);
        rcu_periph_clock_enable(RCU_LCD_DB3);
        rcu_periph_clock_enable(RCU_LCD_DB4);
        rcu_periph_clock_enable(RCU_LCD_DB5);
        rcu_periph_clock_enable(RCU_LCD_DB6);
        rcu_periph_clock_enable(RCU_LCD_DB7);
        
                 /* ����RD */
        gpio_mode_set(PORT_LCD_RD,GPIO_MODE_OUTPUT,GPIO_PUPD_PULLUP,GPIO_LCD_RD);
        gpio_output_options_set(PORT_LCD_RD,GPIO_OTYPE_PP,GPIO_OSPEED_50MHZ,GPIO_LCD_RD);
        gpio_bit_write(PORT_LCD_RD, GPIO_LCD_RD, SET);
        
                 /* ����WR */
        gpio_mode_set(PORT_LCD_WR,GPIO_MODE_OUTPUT,GPIO_PUPD_PULLUP,GPIO_LCD_WR);
        gpio_output_options_set(PORT_LCD_WR,GPIO_OTYPE_PP,GPIO_OSPEED_50MHZ,GPIO_LCD_WR);
        gpio_bit_write(PORT_LCD_WR, GPIO_LCD_WR, SET);
        
                 /* ����DC */
        gpio_mode_set(PORT_LCD_DC,GPIO_MODE_OUTPUT,GPIO_PUPD_PULLUP,GPIO_LCD_DC);
        gpio_output_options_set(PORT_LCD_DC,GPIO_OTYPE_PP,GPIO_OSPEED_50MHZ,GPIO_LCD_DC);
        gpio_bit_write(PORT_LCD_DC, GPIO_LCD_DC, SET);

                 /* ����CS */
        gpio_mode_set(PORT_LCD_CS,GPIO_MODE_OUTPUT,GPIO_PUPD_PULLUP,GPIO_LCD_CS);
        gpio_output_options_set(PORT_LCD_CS,GPIO_OTYPE_PP,GPIO_OSPEED_50MHZ,GPIO_LCD_CS);
        gpio_bit_write(PORT_LCD_CS, GPIO_LCD_CS, SET);
        
                 /* ����RES */
        gpio_mode_set(PORT_LCD_RES,GPIO_MODE_OUTPUT,GPIO_PUPD_PULLUP,GPIO_LCD_RES);
        gpio_output_options_set(PORT_LCD_RES,GPIO_OTYPE_PP,GPIO_OSPEED_50MHZ,GPIO_LCD_RES);
        gpio_bit_write(PORT_LCD_RES, GPIO_LCD_RES, SET);

                 /* ����BLK */
        gpio_mode_set(PORT_LCD_BLK, GPIO_MODE_OUTPUT, GPIO_PUPD_PULLUP, GPIO_LCD_BLK);
        gpio_output_options_set(PORT_LCD_BLK, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, GPIO_LCD_BLK);
        gpio_bit_write(PORT_LCD_BLK, GPIO_LCD_BLK, SET);


                 /* ����DB0 */
        gpio_mode_set(PORT_LCD_DB0, GPIO_MODE_OUTPUT, GPIO_PUPD_PULLUP, GPIO_LCD_DB0);
        gpio_output_options_set(PORT_LCD_DB0, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, GPIO_LCD_DB0);
        gpio_bit_write(PORT_LCD_DB0, GPIO_LCD_DB0, SET);

                 /* ����DB1 */
        gpio_mode_set(PORT_LCD_DB1, GPIO_MODE_OUTPUT, GPIO_PUPD_PULLUP, GPIO_LCD_DB1);
        gpio_output_options_set(PORT_LCD_DB1, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, GPIO_LCD_DB1);
        gpio_bit_write(PORT_LCD_DB1, GPIO_LCD_DB1, SET);
        
                 /* ����DB2 */
        gpio_mode_set(PORT_LCD_DB2, GPIO_MODE_OUTPUT, GPIO_PUPD_PULLUP, GPIO_LCD_DB2);
        gpio_output_options_set(PORT_LCD_DB2, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, GPIO_LCD_DB2);
        gpio_bit_write(PORT_LCD_DB2, GPIO_LCD_DB2, SET);
        
                 /* ����DB3 */
        gpio_mode_set(PORT_LCD_DB3, GPIO_MODE_OUTPUT, GPIO_PUPD_PULLUP, GPIO_LCD_DB3);
        gpio_output_options_set(PORT_LCD_DB3, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, GPIO_LCD_DB3);
        gpio_bit_write(PORT_LCD_DB3, GPIO_LCD_DB3, SET);

                 /* ����DB4 */
        gpio_mode_set(PORT_LCD_DB4, GPIO_MODE_OUTPUT, GPIO_PUPD_PULLUP, GPIO_LCD_DB4);
        gpio_output_options_set(PORT_LCD_DB4, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, GPIO_LCD_DB4);
        gpio_bit_write(PORT_LCD_DB4, GPIO_LCD_DB4, SET);
        
                 /* ����DB5 */
        gpio_mode_set(PORT_LCD_DB5, GPIO_MODE_OUTPUT, GPIO_PUPD_PULLUP, GPIO_LCD_DB5);
        gpio_output_options_set(PORT_LCD_DB5, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, GPIO_LCD_DB5);
        gpio_bit_write(PORT_LCD_DB5, GPIO_LCD_DB5, SET);
        
                 /* ����DB6 */
        gpio_mode_set(PORT_LCD_DB6, GPIO_MODE_OUTPUT, GPIO_PUPD_PULLUP, GPIO_LCD_DB6);
        gpio_output_options_set(PORT_LCD_DB6, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, GPIO_LCD_DB6);
        gpio_bit_write(PORT_LCD_DB6, GPIO_LCD_DB6, SET);
        
                 /* ����DB7 */
        gpio_mode_set(PORT_LCD_DB7, GPIO_MODE_OUTPUT, GPIO_PUPD_PULLUP, GPIO_LCD_DB7);
        gpio_output_options_set(PORT_LCD_DB7, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, GPIO_LCD_DB7);
        gpio_bit_write(PORT_LCD_DB7, GPIO_LCD_DB7, SET);
}


/******************************************************************************
      ����˵����LCD��������д�뺯��
      ������ݣ�dat  Ҫд��Ĵ�������
      ����ֵ��  ��
******************************************************************************/
void LCD_Writ_Bus(u8 dat) 
{	
        LCD_CS_Clr();
        LCD_WR_Clr();
    
        BIT_DB7( (dat>>7)&0x01 );
        BIT_DB6( (dat>>6)&0x01 ); 
        BIT_DB5( (dat>>5)&0x01 );
        BIT_DB4( (dat>>4)&0x01 );
        BIT_DB3( (dat>>3)&0x01 );
        BIT_DB2( (dat>>2)&0x01 );
        BIT_DB1( (dat>>1)&0x01 ); 
        BIT_DB0( (dat>>0)&0x01 ); 

        LCD_WR_Set();
        LCD_CS_Set();
}


/******************************************************************************
      ����˵����LCDд������
      ������ݣ�dat д�������
      ����ֵ��  ��
******************************************************************************/
void LCD_WR_DATA8(u8 dat)
{
	LCD_Writ_Bus(dat);
}


/******************************************************************************
      ����˵����LCDд������
      ������ݣ�dat д�������
      ����ֵ��  ��
******************************************************************************/
void LCD_WR_DATA(u16 dat)
{
	LCD_Writ_Bus(dat>>8);
	LCD_Writ_Bus(dat);
}


/******************************************************************************
      ����˵����LCDд������
      ������ݣ�dat д�������
      ����ֵ��  ��
******************************************************************************/
void LCD_WR_REG(u8 dat)
{
	LCD_DC_Clr();//д����
	LCD_Writ_Bus(dat);
	LCD_DC_Set();//д����
}


/******************************************************************************
      ����˵����������ʼ�ͽ�����ַ
      ������ݣ�x1,x2 �����е���ʼ�ͽ�����ַ
                y1,y2 �����е���ʼ�ͽ�����ַ
      ����ֵ��  ��
******************************************************************************/
void LCD_Address_Set(u16 x1,u16 y1,u16 x2,u16 y2)
{
	if(USE_HORIZONTAL==0)
	{
		LCD_WR_REG(0x2a);//�е�ַ����
		LCD_WR_DATA(x1+52);
		LCD_WR_DATA(x2+52);
		LCD_WR_REG(0x2b);//�е�ַ����
		LCD_WR_DATA(y1+40);
		LCD_WR_DATA(y2+40);
		LCD_WR_REG(0x2c);//������д
	}
	else if(USE_HORIZONTAL==1)
	{
		LCD_WR_REG(0x2a);//�е�ַ����
		LCD_WR_DATA(x1+53);
		LCD_WR_DATA(x2+53);
		LCD_WR_REG(0x2b);//�е�ַ����
		LCD_WR_DATA(y1+40);
		LCD_WR_DATA(y2+40);
		LCD_WR_REG(0x2c);//������д
	}
	else if(USE_HORIZONTAL==2)
	{
		LCD_WR_REG(0x2a);//�е�ַ����
		LCD_WR_DATA(x1+40);
		LCD_WR_DATA(x2+40);
		LCD_WR_REG(0x2b);//�е�ַ����
		LCD_WR_DATA(y1+53);
		LCD_WR_DATA(y2+53);
		LCD_WR_REG(0x2c);//������д
	}
	else
	{
		LCD_WR_REG(0x2a);//�е�ַ����
		LCD_WR_DATA(x1+40);
		LCD_WR_DATA(x2+40);
		LCD_WR_REG(0x2b);//�е�ַ����
		LCD_WR_DATA(y1+52);
		LCD_WR_DATA(y2+52);
		LCD_WR_REG(0x2c);//������д
	}
}

void LCD_Init(void)
{
	LCD_GPIO_Init();//��ʼ��GPIO
	
	LCD_RES_Clr();//��λ
	delay_ms(100);
	LCD_RES_Set();
	delay_ms(100);
	
	LCD_BLK_Set();//�򿪱���
  delay_ms(100);
	
	LCD_WR_REG(0x11); 
	delay_ms(120); 
	LCD_WR_REG(0x36); 
	if(USE_HORIZONTAL==0)LCD_WR_DATA8(0x00);
	else if(USE_HORIZONTAL==1)LCD_WR_DATA8(0xC0);
	else if(USE_HORIZONTAL==2)LCD_WR_DATA8(0x70);
	else LCD_WR_DATA8(0xA0);

	LCD_WR_REG(0x3A);
	LCD_WR_DATA8(0x05);

	LCD_WR_REG(0xB2);
	LCD_WR_DATA8(0x0C);
	LCD_WR_DATA8(0x0C);
	LCD_WR_DATA8(0x00);
	LCD_WR_DATA8(0x33);
	LCD_WR_DATA8(0x33); 

	LCD_WR_REG(0xB7); 
	LCD_WR_DATA8(0x35);  

	LCD_WR_REG(0xBB);
	LCD_WR_DATA8(0x19);

	LCD_WR_REG(0xC0);
	LCD_WR_DATA8(0x2C);

	LCD_WR_REG(0xC2);
	LCD_WR_DATA8(0x01);

	LCD_WR_REG(0xC3);
	LCD_WR_DATA8(0x12);   

	LCD_WR_REG(0xC4);
	LCD_WR_DATA8(0x20);  

	LCD_WR_REG(0xC6); 
	LCD_WR_DATA8(0x0F);    

	LCD_WR_REG(0xD0); 
	LCD_WR_DATA8(0xA4);
	LCD_WR_DATA8(0xA1);

	LCD_WR_REG(0xE0);
	LCD_WR_DATA8(0xD0);
	LCD_WR_DATA8(0x04);
	LCD_WR_DATA8(0x0D);
	LCD_WR_DATA8(0x11);
	LCD_WR_DATA8(0x13);
	LCD_WR_DATA8(0x2B);
	LCD_WR_DATA8(0x3F);
	LCD_WR_DATA8(0x54);
	LCD_WR_DATA8(0x4C);
	LCD_WR_DATA8(0x18);
	LCD_WR_DATA8(0x0D);
	LCD_WR_DATA8(0x0B);
	LCD_WR_DATA8(0x1F);
	LCD_WR_DATA8(0x23);

	LCD_WR_REG(0xE1);
	LCD_WR_DATA8(0xD0);
	LCD_WR_DATA8(0x04);
	LCD_WR_DATA8(0x0C);
	LCD_WR_DATA8(0x11);
	LCD_WR_DATA8(0x13);
	LCD_WR_DATA8(0x2C);
	LCD_WR_DATA8(0x3F);
	LCD_WR_DATA8(0x44);
	LCD_WR_DATA8(0x51);
	LCD_WR_DATA8(0x2F);
	LCD_WR_DATA8(0x1F);
	LCD_WR_DATA8(0x1F);
	LCD_WR_DATA8(0x20);
	LCD_WR_DATA8(0x23);

	LCD_WR_REG(0x21); 

	LCD_WR_REG(0x29); 
}








