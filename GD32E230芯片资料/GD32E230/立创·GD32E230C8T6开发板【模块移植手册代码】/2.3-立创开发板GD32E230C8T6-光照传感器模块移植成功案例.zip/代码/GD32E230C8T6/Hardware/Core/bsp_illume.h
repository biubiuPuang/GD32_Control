#ifndef _BSP_MQ2_H_
#define _BSP_MQ2_H_
 
#include "gd32e23x.h"



#define RCU_ILLUME_GPIO_AO     RCU_GPIOA
#define RCU_ILLUME_GPIO_DO     RCU_GPIOB

#define RCU_ILLUME_ADC      RCU_ADC0
#define RCU_ILLUME_DMA      RCU_DMA1

#define PORT_DMA            DMA1
#define CHANNEL_DMA         DMA_CH0

#define PORT_ADC            ADC0
#define CHANNEL_ADC         ADC_CHANNEL_1

#define PORT_ILLUME_AO      GPIOA
#define GPIO_ILLUME_AO      GPIO_PIN_1

#define PORT_ILLUME_DO      GPIOB
#define GPIO_ILLUME_DO      GPIO_PIN_1

#define GET_DO_IN   gpio_input_bit_get(PORT_ILLUME_DO, GPIO_ILLUME_DO)

 //��������
#define SAMPLES         30
//����ͨ���� 
#define CHANNEL_NUM     1


extern uint16_t gt_adc_val[ SAMPLES ][ CHANNEL_NUM ];  //DMA������
 
void Illume_GPIO_Init(void);
unsigned int Get_Adc_Dma_Value(char CHx);
unsigned int Get_illume_Percentage_value(void);
char Get_DO_In(void);

#endif