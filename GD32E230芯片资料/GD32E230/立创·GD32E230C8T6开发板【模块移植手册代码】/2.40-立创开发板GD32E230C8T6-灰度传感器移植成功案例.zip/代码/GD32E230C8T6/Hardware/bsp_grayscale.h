#ifndef _BSP_GRAYSCALE_H_
#define _BSP_GRAYSCALE_H_

#include "gd32e23x.h"
 
 
#define RCU_GRAYSCALE_OUT       RCU_GPIOA

#define RCU_GRAYSCALE_ADC       RCU_ADC
#define RCU_GRAYSCALE_DMA       RCU_DMA

#define PORT_DMA                DMA
#define CHANNEL_DMA             DMA_CH0

#define PORT_ADC                ADC
#define CHANNEL_ADC             ADC_CHANNEL_1

#define PORT_GRAYSCALE_OUT      GPIOA
#define GPIO_GRAYSCALE_OUT      GPIO_PIN_1


 //��������
#define SAMPLES         30
//����ͨ���� 
#define CHANNEL_NUM     1


extern uint16_t gt_adc_val[ SAMPLES ][ CHANNEL_NUM ];  //DMA������
 

void ADC_DMA_Init(void);
unsigned int Get_Adc_Dma_Value(char CHx);
unsigned int Get_Grayscale_Percentage_Value(void);
#endif
