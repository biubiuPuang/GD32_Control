#ifndef _BSP_MQ5_H_
#define _BSP_MQ5_H_
 
#include "gd32e23x.h"
 
 
#define RCU_MQ5_GPIO_AO    RCU_GPIOA
#define RCU_MQ5_GPIO_DO    RCU_GPIOB

#define RCU_MQ5_ADC     RCU_ADC
#define RCU_MQ5_DMA     RCU_DMA

#define PORT_DMA        DMA1
#define CHANNEL_DMA     DMA_CH0

#define PORT_ADC     	ADC0
#define CHANNEL_ADC     ADC_CHANNEL_1

#define PORT_MQ5_AO     GPIOA
#define GPIO_MQ5_AO     GPIO_PIN_1

#define PORT_MQ5_DO     GPIOB
#define GPIO_MQ5_DO     GPIO_PIN_1

 //��������
#define SAMPLES         30
//����ͨ���� 
#define CHANNEL_NUM     1


extern uint16_t gt_adc_val[ SAMPLES ][ CHANNEL_NUM ];  //DMA������
 

void ADC_DMA_Init(void);
unsigned int Get_Adc_Dma_Value(char CHx);
unsigned int Get_MQ5_Percentage_value(void);
char Get_MQ5_DO_value(void);

#endif