#ifndef _BSP_MQ7_H_
#define _BSP_MQ7_H_
 
#include "gd32e23x.h"
 
 
#define RCU_MQ7_GPIO_AO    RCU_GPIOA
#define RCU_MQ7_GPIO_DO    RCU_GPIOB

#define RCU_MQ7_ADC        RCU_ADC
#define RCU_MQ7_DMA        RCU_DMA

#define PORT_DMA           DMA
#define CHANNEL_DMA        DMA_CH0

#define PORT_ADC           ADC
#define CHANNEL_ADC        ADC_CHANNEL_1

#define PORT_MQ7_AO        GPIOA
#define GPIO_MQ7_AO        GPIO_PIN_1

#define PORT_MQ7_DO        GPIOB
#define GPIO_MQ7_DO        GPIO_PIN_1

 //��������
#define SAMPLES         30
//����ͨ���� 
#define CHANNEL_NUM     1


extern uint16_t gt_adc_val[ SAMPLES ][ CHANNEL_NUM ];  //DMA������
 

void ADC_DMA_Init(void);
unsigned int Get_Adc_Dma_Value(char CHx);
unsigned int Get_MQ7_Percentage_value(void);
char Get_MQ7_DO_value(void);

#endif