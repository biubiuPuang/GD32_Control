#ifndef _BSP_RTC_H__
#define _BSP_RTC_H__

#include "gd32e23x.h"

void rtc_config(void);
void RtcShowTime(void);


#endif
