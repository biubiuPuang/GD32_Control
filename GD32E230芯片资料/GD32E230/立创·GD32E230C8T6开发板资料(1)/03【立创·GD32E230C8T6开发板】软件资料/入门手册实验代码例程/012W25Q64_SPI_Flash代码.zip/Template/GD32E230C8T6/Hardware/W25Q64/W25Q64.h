#ifndef _W25Q64_H__
#define _W25Q64_H__

#include "gd32e23x.h"

#define W25QXX_CS_ON(x)		gpio_bit_write(GPIOA, GPIO_PIN_4, x?1:0);

void W25Q64_Config(void);
uint16_t W25Q64_readID(void);
void W25Q64_write(uint8_t* buffer, uint32_t addr, uint16_t numbyte);
void W25Q64_read(uint8_t* buffer,uint32_t read_addr,uint16_t read_length) ;



#endif
