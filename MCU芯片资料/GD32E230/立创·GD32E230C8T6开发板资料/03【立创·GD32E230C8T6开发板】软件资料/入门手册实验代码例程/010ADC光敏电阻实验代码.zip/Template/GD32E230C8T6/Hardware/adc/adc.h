#include "gd32e23x.h"
#include "systick.h"

/* PA1 ADC_IN1 */
#define BSP_ADC_GPIO_RCU     RCU_GPIOA
#define BSP_ADC_GPIO_PORT    GPIOA
#define BSP_ADC_GPIO_PIN     GPIO_PIN_1
 
/* PA1 ADC_IN1 */
#define BSP_ADC_RCU         RCU_ADC
#define BSP_ADC             ADC
#define BSP_ADC_CHANNEL     ADC_CHANNEL_1

// ��ʼ��ADC
void ADC_Config(void);

// ��ȡADCֵ
unsigned int Get_ADC_Value(uint8_t  ADC_CHANNEL_x);
