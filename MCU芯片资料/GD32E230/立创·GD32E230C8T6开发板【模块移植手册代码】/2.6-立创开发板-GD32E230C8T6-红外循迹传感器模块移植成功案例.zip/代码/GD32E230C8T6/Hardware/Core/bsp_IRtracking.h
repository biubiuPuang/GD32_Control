#ifndef _BSP_IRTRACKING_H_
#define _BSP_IRTRACKING_H_
 
#include "gd32e23x.h"


#define RCU_IR_AO           RCU_GPIOA
#define PORT_IR_AO          GPIOA
#define GPIO_IR_AO          GPIO_PIN_1

#define RCU_IR_DO           RCU_GPIOB
#define PORT_IR_DO          GPIOB
#define GPIO_IR_DO          GPIO_PIN_1

#define RCU_IR_ADC          RCU_ADC0
#define PORT_IR_ADC         ADC0
#define CHANNEL_IR_ADC      ADC_CHANNEL_1


//����ͨ���� 
#define CHANNEL_NUM     1

#define IR_DO   gpio_input_bit_get(PORT_IR_DO,GPIO_IR_DO)

void IRtracking_GPIO_Init(void);//��ʼ��
unsigned int Get_ADC_Value(unsigned int num);//��ȡAOֵ
unsigned char Get_DO_Num(void);//��ȡDOֵ
#endif

