#ifndef _BSP_IRDISTANCE_H_
#define _BSP_IRDISTANCE_H_
 
#include "gd32e23x.h"
 
 
#define RCU_IRDISTANCE_GPIO    RCU_GPIOA
#define RCU_IRDISTANCE_ADC     RCU_ADC0
#define RCU_IRDISTANCE_DMA     RCU_DMA1

#define PORT_DMA        	DMA1
#define CHANNEL_DMA     	DMA_CH0

#define PORT_ADC     		ADC0
#define CHANNEL_ADC     	ADC_CHANNEL_1

#define PORT_IRDISTANCE     GPIOA
#define GPIO_IRDISTANCE     GPIO_PIN_1


 //��������
#define SAMPLES         100
//����ͨ���� 
#define CHANNEL_NUM     1


extern uint16_t gt_adc_val[ SAMPLES ][ CHANNEL_NUM ];  //DMA������
 
void ADC_DMA_Init(void);
float Get_Adc_Dma_Value(char CHx);
double Get_IRdistance_Distance(void);

#endif
