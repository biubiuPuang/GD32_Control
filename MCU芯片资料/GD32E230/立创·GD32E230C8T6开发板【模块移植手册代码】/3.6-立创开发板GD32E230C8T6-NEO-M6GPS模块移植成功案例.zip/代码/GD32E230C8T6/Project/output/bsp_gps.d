./output/bsp_gps.o: ..\Hardware\bsp_gps.c ..\Hardware\bsp_gps.h \
  ..\Firmware\CMSIS\GD\GD32E23x\Include\gd32e23x.h \
  F:\Keil5MDK\ARM\CMSIS\5.9.0\CMSIS\Core\Include\core_cm23.h \
  F:\Keil5MDK\ARM\ARMCLANG\Bin\..\include\stdint.h \
  F:\Keil5MDK\ARM\CMSIS\5.9.0\CMSIS\Core\Include\cmsis_version.h \
  F:\Keil5MDK\ARM\CMSIS\5.9.0\CMSIS\Core\Include\cmsis_compiler.h \
  F:\Keil5MDK\ARM\CMSIS\5.9.0\CMSIS\Core\Include\cmsis_armclang.h \
  ..\Firmware\CMSIS\GD\GD32E23x\Include\system_gd32e23x.h \
  ..\User\gd32e23x_libopt.h \
  ..\Firmware\GD32E23x_standard_peripheral\Include\gd32e23x_adc.h \
  ..\Firmware\GD32E23x_standard_peripheral\Include\gd32e23x_crc.h \
  ..\Firmware\GD32E23x_standard_peripheral\Include\gd32e23x_dbg.h \
  ..\Firmware\GD32E23x_standard_peripheral\Include\gd32e23x_dma.h \
  ..\Firmware\GD32E23x_standard_peripheral\Include\gd32e23x_exti.h \
  ..\Firmware\GD32E23x_standard_peripheral\Include\gd32e23x_fmc.h \
  ..\Firmware\GD32E23x_standard_peripheral\Include\gd32e23x_gpio.h \
  ..\Firmware\GD32E23x_standard_peripheral\Include\gd32e23x_syscfg.h \
  ..\Firmware\GD32E23x_standard_peripheral\Include\gd32e23x_i2c.h \
  ..\Firmware\GD32E23x_standard_peripheral\Include\gd32e23x_fwdgt.h \
  ..\Firmware\GD32E23x_standard_peripheral\Include\gd32e23x_pmu.h \
  ..\Firmware\GD32E23x_standard_peripheral\Include\gd32e23x_rcu.h \
  ..\Firmware\GD32E23x_standard_peripheral\Include\gd32e23x_rtc.h \
  ..\Firmware\GD32E23x_standard_peripheral\Include\gd32e23x_spi.h \
  ..\Firmware\GD32E23x_standard_peripheral\Include\gd32e23x_timer.h \
  ..\Firmware\GD32E23x_standard_peripheral\Include\gd32e23x_usart.h \
  ..\Firmware\GD32E23x_standard_peripheral\Include\gd32e23x_wwdgt.h \
  ..\Firmware\GD32E23x_standard_peripheral\Include\gd32e23x_misc.h \
  ..\Firmware\GD32E23x_standard_peripheral\Include\gd32e23x_cmp.h \
  ..\User\systick.h F:\Keil5MDK\ARM\ARMCLANG\Bin\..\include\stdio.h \
  F:\Keil5MDK\ARM\ARMCLANG\Bin\..\include\stdlib.h \
  F:\Keil5MDK\ARM\ARMCLANG\Bin\..\include\string.h
