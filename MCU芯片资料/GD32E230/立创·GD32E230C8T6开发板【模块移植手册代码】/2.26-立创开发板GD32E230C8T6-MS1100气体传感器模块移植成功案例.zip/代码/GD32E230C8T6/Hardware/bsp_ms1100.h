#ifndef _BSP_MS1100_H_
#define _BSP_MS1100_H_

#include "gd32e23x.h"


#define RCU_MS1100_AO           RCU_GPIOA
#define PORT_MS1100_AO          GPIOA
#define GPIO_MS1100_AO          GPIO_PIN_1

#define RCU_MS1100_DO           RCU_GPIOB
#define PORT_MS1100_DO          GPIOB
#define GPIO_MS1100_DO          GPIO_PIN_1

#define RCU_MS1100_ADC          RCU_ADC
#define PORT_MS1100_ADC         ADC
#define CHANNEL_MS1100_ADC      ADC_CHANNEL_1


//����ͨ���� 
#define CHANNEL_NUM     1

#define MS1100_DO   gpio_input_bit_get(PORT_MS1100_DO,GPIO_MS1100_DO)

void MS1100_GPIO_Init(void);//��ʼ��
unsigned int Get_ADC_Value(unsigned int num);//��ȡAOֵ
unsigned char Get_DO_Num(void);//��ȡDOֵ
#endif

