#ifndef __LCD_INIT_H
#define __LCD_INIT_H

#include "gd32e23x.h"
#include "systick.h"

#ifndef u8
#define u8 uint8_t
#endif

#ifndef u16
#define u16 uint16_t
#endif

#ifndef u32
#define u32 uint32_t
#endif


#define USE_HORIZONTAL 0  //���ú�������������ʾ 0��1Ϊ���� 2��3Ϊ����


#define LCD_W 240
#define LCD_H 240


//-----------------LCD�˿���ֲ---------------- 
//VCC - 3.3V

#define RCU_LCD_SCL     RCU_GPIOA//SCL
#define PORT_LCD_SCL    GPIOA
#define GPIO_LCD_SCL    GPIO_PIN_5

#define RCU_LCD_SDA     RCU_GPIOA//SDA
#define PORT_LCD_SDA    GPIOA
#define GPIO_LCD_SDA    GPIO_PIN_7

#define RCU_LCD_CS      RCU_GPIOA//CS
#define PORT_LCD_CS     GPIOA
#define GPIO_LCD_CS     GPIO_PIN_4

#define RCU_LCD_DC      RCU_GPIOB //DC
#define PORT_LCD_DC     GPIOB
#define GPIO_LCD_DC     GPIO_PIN_1

#define RCU_LCD_RES     RCU_GPIOB//RES
#define PORT_LCD_RES    GPIOB
#define GPIO_LCD_RES    GPIO_PIN_0

#define RCU_LCD_BLK     RCU_GPIOB//BLK
#define PORT_LCD_BLK    GPIOB
#define GPIO_LCD_BLK    GPIO_PIN_10

#define RCU_LCD_FSO     RCU_GPIOC//FSO
#define PORT_LCD_FSO    GPIOC
#define GPIO_LCD_FSO    GPIO_PIN_15

#define RCU_LCD_CS2     RCU_GPIOA//CS2
#define PORT_LCD_CS2    GPIOA
#define GPIO_LCD_CS2    GPIO_PIN_1


#define RCU_SPI_HARDWARE RCU_SPI0
#define PORT_SPI         SPI0
#define LINE_AF_SPI      GPIO_AF_0



//-----------------LCD�˿ڶ���---------------- 
#define LCD_SCLK_Clr() gpio_bit_write(PORT_LCD_SCL, GPIO_LCD_SCL, RESET)//SCL=SCLK
#define LCD_SCLK_Set() gpio_bit_write(PORT_LCD_SCL, GPIO_LCD_SCL, SET)

#define LCD_MOSI_Clr() gpio_bit_write(PORT_LCD_SDA, GPIO_LCD_SDA, RESET)//SDA=MOSI
#define LCD_MOSI_Set() gpio_bit_write(PORT_LCD_SDA, GPIO_LCD_SDA, SET)

#define LCD_RES_Clr()  gpio_bit_write(PORT_LCD_RES, GPIO_LCD_RES, RESET)//RES
#define LCD_RES_Set()  gpio_bit_write(PORT_LCD_RES, GPIO_LCD_RES, SET)

#define LCD_DC_Clr()   gpio_bit_write(PORT_LCD_DC, GPIO_LCD_DC, RESET)//DC
#define LCD_DC_Set()   gpio_bit_write(PORT_LCD_DC, GPIO_LCD_DC, SET)
                       
#define LCD_CS_Clr()   gpio_bit_write(PORT_LCD_CS, GPIO_LCD_CS, RESET)//CS
#define LCD_CS_Set()   gpio_bit_write(PORT_LCD_CS, GPIO_LCD_CS, SET)

#define LCD_BLK_Clr()  gpio_bit_write(PORT_LCD_BLK, GPIO_LCD_BLK, RESET)//BLK
#define LCD_BLK_Set()  gpio_bit_write(PORT_LCD_BLK, GPIO_LCD_BLK, SET)

//��ȡ�ֿ���������
#define ZK_MISO        gpio_input_bit_get(PORT_LCD_FSO,GPIO_LCD_FSO)//MISO  

#define ZK_CS_Clr()    gpio_bit_write(PORT_LCD_CS2,GPIO_LCD_CS2,RESET)//CS2 �ֿ�Ƭѡ
#define ZK_CS_Set()    gpio_bit_write(PORT_LCD_CS2,GPIO_LCD_CS2,SET)  	




void LCD_GPIO_Init(void);//��ʼ��GPIO
void LCD_Writ_Bus(u8 dat);//ģ��SPIʱ��
void LCD_WR_DATA8(u8 dat);//д��һ���ֽ�
void LCD_WR_DATA(u16 dat);//д�������ֽ�
void LCD_WR_REG(u8 dat);//д��һ��ָ��
void LCD_Address_Set(u16 x1,u16 y1,u16 x2,u16 y2);//�������꺯��
void LCD_Init(void);//LCD��ʼ��
#endif




