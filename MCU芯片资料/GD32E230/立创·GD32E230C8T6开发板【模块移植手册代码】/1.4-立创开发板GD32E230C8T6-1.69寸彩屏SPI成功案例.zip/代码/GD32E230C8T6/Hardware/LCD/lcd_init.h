#ifndef __LCD_INIT_H
#define __LCD_INIT_H

// lcd_init.h
#include <stdint.h>
#include "gd32e23x.h"
#include "systick.h"

#ifndef u8
#define u8 uint8_t
#endif

#ifndef u16
#define u16 uint16_t
#endif

#ifndef u32
#define u32 uint32_t
#endif

//-----------------LCD�˿���ֲ---------------- 
//VCC - 3.3V
//SCL - PA0
//SDA - PA1
//RES - PA2(���Խ��븴λ)
//DC  - PA3
//CS  - PA4
//BLK - PA5
#define RCU_LCD_SCL     RCU_GPIOA//SCK
#define PORT_LCD_SCL    GPIOA
#define GPIO_LCD_SCL    GPIO_PIN_0

#define RCU_LCD_SDA     RCU_GPIOA//MOSI
#define PORT_LCD_SDA    GPIOA
#define GPIO_LCD_SDA    GPIO_PIN_1

#define RCU_LCD_CS      RCU_GPIOA//NSS
#define PORT_LCD_CS     GPIOA
#define GPIO_LCD_CS     GPIO_PIN_4

#define RCU_LCD_DC      RCU_GPIOA //DC
#define PORT_LCD_DC     GPIOA
#define GPIO_LCD_DC     GPIO_PIN_3

#define RCU_LCD_RES     RCU_GPIOA//RES
#define PORT_LCD_RES    GPIOA
#define GPIO_LCD_RES    GPIO_PIN_2

#define RCU_LCD_BLK     RCU_GPIOA//BLK
#define PORT_LCD_BLK    GPIOA
#define GPIO_LCD_BLK    GPIO_PIN_5



#define USE_HORIZONTAL 0  //���ú�������������ʾ 0��1Ϊ���� 2��3Ϊ����


#if USE_HORIZONTAL==0||USE_HORIZONTAL==1
#define LCD_W 240
#define LCD_H 280

#else
#define LCD_W 280
#define LCD_H 240
#endif




//-----------------LCD�˿ڶ���---------------- 

#define LCD_SCLK_Clr() gpio_bit_write(PORT_LCD_SCL, GPIO_LCD_SCL, RESET)//SCL=SCLK
#define LCD_SCLK_Set() gpio_bit_write(PORT_LCD_SCL, GPIO_LCD_SCL, SET)

#define LCD_MOSI_Clr() gpio_bit_write(PORT_LCD_SDA, GPIO_LCD_SDA, RESET)//SDA=MOSI
#define LCD_MOSI_Set() gpio_bit_write(PORT_LCD_SDA, GPIO_LCD_SDA, SET)

#define LCD_RES_Clr()  gpio_bit_write(PORT_LCD_RES, GPIO_LCD_RES, RESET)//RES
#define LCD_RES_Set()  gpio_bit_write(PORT_LCD_RES, GPIO_LCD_RES, SET)

#define LCD_DC_Clr()   gpio_bit_write(PORT_LCD_DC, GPIO_LCD_DC, RESET)//DC
#define LCD_DC_Set()   gpio_bit_write(PORT_LCD_DC, GPIO_LCD_DC, SET)
                       
#define LCD_CS_Clr()   gpio_bit_write(PORT_LCD_CS, GPIO_LCD_CS, RESET)//CS
#define LCD_CS_Set()   gpio_bit_write(PORT_LCD_CS, GPIO_LCD_CS, SET)

#define LCD_BLK_Clr()  gpio_bit_write(PORT_LCD_BLK, GPIO_LCD_BLK, RESET)//BLK
#define LCD_BLK_Set()  gpio_bit_write(PORT_LCD_BLK, GPIO_LCD_BLK, SET)



void LCD_GPIO_Init(void);//��ʼ��GPIO
void LCD_Writ_Bus(u8 dat);//ģ��SPIʱ��
void LCD_WR_DATA8(u8 dat);//д��һ���ֽ�
void LCD_WR_DATA(u16 dat);//д�������ֽ�
void LCD_WR_REG(u8 dat);//д��һ��ָ��
void LCD_Address_Set(u16 x1,u16 y1,u16 x2,u16 y2);//�������꺯��
void LCD_Init(void);//LCD��ʼ��
#endif




