#ifndef _BSP_HX711_H_
#define _BSP_HX711_H_

#include "gd32e23x.h"

//�˿���ֲ
#define RCU_SCK RCU_GPIOB
#define PORT_SCK GPIOB
#define GPIO_SCK GPIO_PIN_8

#define RCU_DT RCU_GPIOB
#define PORT_DT GPIOB
#define GPIO_DT GPIO_PIN_9

//����DT���ģʽ
#define DT_OUT()        gpio_mode_set(PORT_DT,GPIO_MODE_OUTPUT,GPIO_MODE_OUTPUT,GPIO_DT)
//����DT����ģʽ
#define DT_IN()        gpio_mode_set(PORT_DT,GPIO_MODE_INPUT,GPIO_MODE_OUTPUT,GPIO_DT)
//��ȡDT���ŵĵ�ƽ�仯
#define DT_GET()        gpio_input_bit_get(PORT_DT,GPIO_DT)
//DT��SCK���
#define DT(x)          gpio_bit_write(PORT_DT,GPIO_DT, (x?SET:RESET))
#define SCK(x)          gpio_bit_write(PORT_SCK,GPIO_SCK, (x?SET:RESET))

void HX711_GPIO_Init(void);
float Get_Weight(void);
void Get_Maopi(void);
#endif
