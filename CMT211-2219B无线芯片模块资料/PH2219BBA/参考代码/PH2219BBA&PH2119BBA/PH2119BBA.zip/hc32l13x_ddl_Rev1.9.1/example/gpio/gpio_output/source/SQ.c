
#include "SQ.h"
#include "gpio.h"

void SQ(void)
{
	                  
	Sysctrl_SetPeripheralGate(SysctrlPeripheralGpio,TRUE);//ʹ��GPIOģ��ʱ��
	stc_gpio_cfg_t stcGpioCfg;//IO ���ýṹ��ָ��
	DDL_ZERO_STRUCT(stcGpioCfg);//��������������
	stcGpioCfg.enDir=GpioDirOut;//���
	Gpio_Init(GpioPortB, GpioPin3, &stcGpioCfg);//SClK
	Gpio_Init(GpioPortD, GpioPin2, &stcGpioCfg);//csb
	Gpio_Init(GpioPortA, GpioPin4, &stcGpioCfg);//fcsb
	Gpio_Init(GpioPortB, GpioPin4, &stcGpioCfg);//SDIO
	stcGpioCfg.enDir=GpioDirIn;//����
	Gpio_Init(GpioPortB, GpioPin5, &stcGpioCfg);//GPIO1
	Gpio_Init(GpioPortB, GpioPin6, &stcGpioCfg);//GPIO2
	Gpio_Init(GpioPortB, GpioPin7, &stcGpioCfg);//GPIO3
	
}


